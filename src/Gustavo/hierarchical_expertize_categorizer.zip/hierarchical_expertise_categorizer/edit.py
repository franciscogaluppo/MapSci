#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import os
import warnings

from sklearn.externals import joblib
from unicodedata import normalize, category


class EDiT(object):
    """
    EDiT - Expertise Discovery Tool v 1.0.

    Parameter
    ---------------------------
    description: str, optional (default='EDiT - Expertise Discovery Tool v 1.0.')
        Hierarchical Categorization for Expertise Profiling API

    Attributes
    ---------------------------
    description: str
        Hierarchical Expertise Categorizer v 1.0.

    parser: argparse
        Command line argument parser object
    """

    def __init__(self, description='EDiT - Expertise Discovery Tool v 1.0.'):
        self.description = description
        self.parser = argparse.ArgumentParser(description=self.description)

        self.__init_parser__()

        self.args = self.parse_args()

        self.vectorizer = joblib.load(''.join(['./models/', self.args.set,'/vectorizer.plk']))

    def __init_parser__(self):
        self.parser.add_argument('-m', '--method', type=str, help='Which of the API methods should be executed - \n\n'
                                 'first: categorize a string using the first (upper) level of the hierarchical model\n\n'
                                 'second: categorize a string using the second level of the hierarchical model\n\n'
                                 'third: categorize a string using the third (lower) level of the hierarchical model\n\n'
                                 'hierarchical: categorize a string using the complete hierarchical model\n\n'
                                 'individual: categorize a string in all levels but not considering the hierarchical'
                                 ' model',
                                 default='first', choices=['first', 'second', 'third', 'hierarchical', 'individual'])

        self.parser.add_argument('-s', '--set', type=str, help='Select TTW-Set or ETW-Set classifying models', default='ttw',
                                 choices=['ttw', 'etw'])

        self.parser.add_argument('--str', type=str, help='A Portuguese string containing a thesis/dissertation title '
                                                         'from a researcher.', default=None)

        self.parser.add_argument('--proba', dest='proba', action='store_true', help='Returns prediction probability')

    def parse_args(self):
        return self.parser.parse_args()

    def first(self):
        if self.args.str is None:
            print 'No string found. Check you command line: edit.py --method <method> ' \
                  '--str <str>'
        else:
            estimator = joblib.load(''.join(['./models/', self.args.set, '/1/major_area.plk']))
            probabilities = estimator.predict_proba(self.vectorizer.transform([str_normalize(self.args.str)]))
            prediction = zip(estimator.classes_, probabilities[0])
            prediction.sort(key=lambda tup: tup[1], reverse=True)

            print 'Class: {0}'.format(prediction[0][0].capitalize())
            if self.args.proba:
                print 'Proba: {0}'.format(round(prediction[0][1], 5))

    def second(self):
        if self.args.str is None:
            print 'No string found. Check you command line: edit.py --method <method> ' \
                  '--str <str>'
        else:
            predictions = list()
            models = list()
            models.extend([name for name in os.listdir(''.join(['./models/', self.args.set, '/2/']))])
            for model in models:
                estimator = joblib.load(''.join(['./models/', self.args.set, '/2/', model]))
                probabilities = estimator.predict_proba(self.vectorizer.transform([str_normalize(self.args.str)]))
                prediction = zip(estimator.classes_, probabilities[0])
                prediction.sort(key=lambda tup: tup[1], reverse=True)
                predictions.append(prediction[0])
            predictions.sort(key=lambda tup: tup[1], reverse=True)

            print 'Class: {0}'.format(prediction[0][0].capitalize())
            if self.args.proba:
                print 'Proba: {0}'.format(round(prediction[0][1], 5))

    def third(self):
        if self.args.str is None:
            print 'No string found. Check you command line: edit.py --method <method> ' \
                  '--str <str>'
        else:
            predictions = list()
            models = list()
            models.extend([name for name in os.listdir(''.join(['./models/', self.args.set, '/3/']))])
            for model in models:
                estimator = joblib.load(''.join(['./models/', self.args.set, '/3/', model]))
                probabilities = estimator.predict_proba(self.vectorizer.transform([str_normalize(self.args.str)]))
                prediction = zip(estimator.classes_, probabilities[0])
                prediction.sort(key=lambda tup: tup[1], reverse=True)
                predictions.append(prediction[0])
            predictions.sort(key=lambda tup: tup[1], reverse=True)

            print 'Class: {0}'.format(prediction[0][0].capitalize())
            if self.args.proba:
                print 'Proba: {0}'.format(round(prediction[0][1], 5))

    def hierarchical(self):
        if self.args.str is None:
            print 'No string found. Check you command line: edit.py --method <method> ' \
                  '--str <str>'
        else:
            estimator = joblib.load(''.join(['./models/', self.args.set, '/1/major_area.plk']))
            probabilities = estimator.predict_proba(self.vectorizer.transform([str_normalize(self.args.str)]))
            prediction = zip(estimator.classes_, probabilities[0])
            prediction.sort(key=lambda tup: tup[1], reverse=True)

            print '1st level eval'
            print 'Class: {0}'.format(prediction[0][0].capitalize())
            if self.args.proba:
                print 'Proba: {0}'.format(round(prediction[0][1], 5))
            print '--------------------------------------------------'
            estimator = joblib.load(''.join(['./models/', self.args.set, '/2/', prediction[0][0].replace(' ', '_'), '.plk']))
            probabilities = estimator.predict_proba(self.vectorizer.transform([str_normalize(self.args.str)]))
            prediction = zip(estimator.classes_, probabilities[0])
            prediction.sort(key=lambda tup: tup[1], reverse=True)

            print '2nd level eval'
            print 'Class: {0}'.format(prediction[0][0].capitalize())
            if self.args.proba:
                print 'Proba: {0}'.format(round(prediction[0][1], 5))
            print '--------------------------------------------------'
            estimator = joblib.load(''.join(['./models/', self.args.set, '/3/', prediction[0][0].replace(' ', '_'), '.plk']))
            probabilities = estimator.predict_proba(self.vectorizer.transform([str_normalize(self.args.str)]))
            prediction = zip(estimator.classes_, probabilities[0])
            prediction.sort(key=lambda tup: tup[1], reverse=True)

            print '3rd level eval'
            print 'Class: {0}'.format(prediction[0][0].capitalize())
            if self.args.proba:
                print 'Proba: {0}'.format(round(prediction[0][1], 5))

    def individual(self):
        print '1st level eval'
        self.first()
        print '--------------------------------------------------'
        print '2nd level eval'
        self.second()
        print '--------------------------------------------------'
        print '3rd level eval'
        self.third()

    def run(self):
        if self.args.method == 'first':
            self.first()
        if self.args.method == 'second':
            self.second()
        if self.args.method == 'third':
            self.third()
        if self.args.method == 'hierarchical':
            self.hierarchical()
        if self.args.method == 'individual':
            self.individual()


def strip_accents(s):
    """
    Remove accents from a string
    :param s: string to remove the accents
    :return: string with the accents removed
    """
    return ''.join(c for c in normalize('NFD', s) if category(c) != 'Mn')


def str_normalize(s):
    """
    Normalize a text string
    :param s: string to be normalized
    :return: string normalized
    """
    return strip_accents(unicode(s.strip().replace('\t', ' '), 'utf-8')).lower()

if __name__ == '__main__':
    warnings.filterwarnings('ignore')
    app = EDiT()
    app.run()
